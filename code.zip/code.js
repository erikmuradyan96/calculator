let input = document.querySelector(".input")
function avelacneltiv(number){
    input.value += number
}

function hashvel(){
    input.value = eval(input.value)
}